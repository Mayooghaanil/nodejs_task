  module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "bubble_node_app"
  };
  
  