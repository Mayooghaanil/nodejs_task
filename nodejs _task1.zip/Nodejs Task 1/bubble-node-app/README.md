HTML And CSS setup with Node JS unsing EJS Engine
